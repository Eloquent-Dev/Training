const audio = document.querySelector("#bg-audio")

audio.volume = 0.1